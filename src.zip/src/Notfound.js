import React from 'react'
import './notfound.css'
export default function Notfound() {
    return (
        <div className="card">
            <h1 >Page Not Found!</h1>
            <h3 >Error 404</h3>
        </div>
    )
}
